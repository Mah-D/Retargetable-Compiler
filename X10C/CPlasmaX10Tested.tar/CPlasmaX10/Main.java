import jplasmax10.parser.JPlasmaX10Parser;
import jplasmax10.parser.ParseException;
import jplasmax10.syntaxtree.*;
import jplasmax10.visitor.*;

public class Main {
   public static void main(String [] args) {
      try {
         Node root = new JPlasmaX10Parser(System.in).File();
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
}

