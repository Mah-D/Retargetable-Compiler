package jplasmax10.visitor;

public class PairsTypeName {
	String myName;
	String type;
	public String getMyName() {
		return myName;
	}
	public void setMyName(String myName) {
		this.myName = myName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public PairsTypeName(String myName, String type) {
		this.myName = myName;
		this.type = type;
	}
	
}
